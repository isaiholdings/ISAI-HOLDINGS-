// =====================================================
// ISAI HOLDINGS 予約カレンダー
// =====================================================
// ここに「予約済みの日」を入力すると、その日が●（予定あり）になります。
// 例：
// const booked = ["2026-11-10", "2026-11-11", "2026-12-20"];
//
// 現在は分かりやすさを優先して、この1か所だけ変更する仕組みです。
// 本格運用ではGoogleカレンダー連携に変更できます。
// =====================================================
const booked = [];

const days = document.getElementById("days");
const month = document.getElementById("month");
let view = new Date();
view.setDate(1);

function drawCalendar() {
  const year = view.getFullYear();
  const mon = view.getMonth();
  month.textContent = `${year}年 ${mon + 1}月`;
  days.innerHTML = "";

  const first = new Date(year, mon, 1).getDay();
  const last = new Date(year, mon + 1, 0).getDate();

  for (let i = 0; i < first; i++) {
    const blank = document.createElement("button");
    blank.className = "muted";
    days.appendChild(blank);
  }

  for (let d = 1; d <= last; d++) {
    const button = document.createElement("button");
    const key = `${year}-${String(mon + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
    button.textContent = d;
    if (booked.includes(key)) {
      button.className = "booked";
      button.title = "予定あり";
    }
    days.appendChild(button);
  }
}

document.getElementById("prev").addEventListener("click", () => {
  view.setMonth(view.getMonth() - 1);
  drawCalendar();
});
document.getElementById("next").addEventListener("click", () => {
  view.setMonth(view.getMonth() + 1);
  drawCalendar();
});

drawCalendar();
