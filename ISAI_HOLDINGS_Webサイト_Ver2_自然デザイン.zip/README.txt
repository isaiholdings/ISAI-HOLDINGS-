# ISAI HOLDINGS Webサイト Ver.2

## まずは無料で公開できます
このサイトは HTML / CSS / JavaScript だけで動く「静的Webサイト」です。
レンタルサーバーを契約しなくても、GitHub Pages / Cloudflare Pages などで無料公開できます。

## ファイル
- index.html：ホームページ本体
- style.css：色・背景・レイアウト
- script.js：予約カレンダー
- isai-logo.jpg：今回いただいた名刺画像から切り出したISAI HOLDINGSロゴ

## 予約カレンダーについて
今は「予約済みの日」を script.js の冒頭にある booked に入力する方式です。

例：
const booked = ["2026-11-10", "2026-11-11"];

入力後、サイトを再アップロードすると、その日が「● 予定あり」になります。

これは無料で簡単な初期版です。
複数の人がリアルタイムで予約状況を管理するなら、次の段階でGoogleカレンダー連携に変更するのがおすすめです。

## メール
予約・問い合わせ先：
kazuki.ski0223@icloud.com
